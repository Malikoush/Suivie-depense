<template>
    <article>
        <article>
            <h2>Nouvelle transaction</h2>
        </article>
        <form @submit.prevent="onSubmit">
            <label>Nom Catégorie :</label>
            <p :class="{ invisible: !err3 }">Erreur: Date invalide</p>
            <input type="date" v-model="new_Catégorie"><br>

            <button type="submit">
                Valider
            </button>
        </form>
    </article>
</template>

<script setup lang="ts">
import { ref } from 'vue';

const new_Catégorie = ref<string>("")

const err3 = ref<boolean>(false)

const onSubmit = () => { }
</script>

<style></style>

