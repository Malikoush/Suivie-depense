<template>
  <RouterLink to="/new-catégorie">categorie</RouterLink>
  <RouterView></RouterView>
</template>

<script setup lang="ts">
import { ref, computed, provide } from 'vue'
import type { Transaction } from '@/entities/transaction';
import { Category } from '@/entities/category';

const transactions = ref<Transaction[]>([
  {
    id: 1,
    description: "cadeau mamie",
    date: new Date(2023, 3, 27),
    amount: 50_00n,
  },
  {
    id: 2,
    description: "Macdo",
    date: new Date(2023, 3, 25),
    amount: -15_00n,
  },
  {
    id: 3,
    description: "Paypal Emil",
    date: new Date(2023, 3, 25),
    amount: 67_00n,
  },
  {
    id: 4,
    description: "Location ski",
    date: new Date(2023, 3, 24),
    amount: -35_00n,
  },
  {
    id: 5,
    description: "JF Crédits",
    date: new Date(2023, 3, 23),
    amount: 200_00n,
  }
])

const categorys = ref<Category[]>([

])

provide('transaction', {
  transactions: transactions,
  addTransaction: addTransaction
})



function addTransaction(new_date: string, description: string, amount: number) {
  transactions.value.push({
    id: Math.max(...transactions.value.map(t => t.id)) + 1,
    description: description,
    date: new Date(new_date),
    amount: BigInt(amount * 100)
  });
};
function addCategory(name: string): void {
  categorys.value.push(new Category{
    1,
    name,
  });
};

const Total = computed(() => {
  return transactions.value.reduce((total, transaction) => total + transaction.amount, 0n);
});
</script>

<style >
#solde {
  background-color: #333;
  border-bottom: 3px #ffffff solid;
  color: #ffffff;
  font-weight: bold;
  text-align: left;
  padding: 10px;

}
</style>
