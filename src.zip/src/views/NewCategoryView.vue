<script setup lang="ts">
import CategoryForm from '@/components/CategoryForm.vue';
import { useRouter } from 'vue-router'
const router = useRouter();

function onNewCategory() { }
</script>

<template>
    <CategoryForm v-on:new-category="onNewCategory" />
</template>