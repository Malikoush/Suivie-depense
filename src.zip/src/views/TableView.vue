<template>
  <div>
    <h2 id="solde">SOLDE RESTANT : {{ ToEuro(Total) }}</h2>
    <Tab :transactions="transactions" />
    <RouterLink to="/new-transaction" class="new-transaction-btn">Nouvelle transaction</RouterLink>
  </div>
</template>

<script setup lang="ts">
import { inject, computed, type Ref } from 'vue';
import type { Transaction } from '@/entities/transaction';
import Tab from '@/components/Tab.vue'
import { ToEuro } from '@/utils/ToEuro'

const transactions = inject<{ transactions: Ref<Transaction[]> }>('transaction')!.transactions;

const Total = computed(() => {
  return transactions.value.reduce((total, transaction) => total + transaction.amount, 0n);
});

</script>

<style>
.new-transaction-btn {
  padding: 10px 20px;
  background-color: #333;
  color: #fff;
  border-radius: 5px;
  margin-top: 10px;
  display: inline-block;
  vertical-align: top;
}

.new-transaction-btn:hover {
  background-color: #444;
}
</style>