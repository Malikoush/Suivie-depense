<template>
  <div>
    <Form v-on:new-transaction="onSubmit" />
    <RouterLink to="/" class="cancel-btn">Annuler</RouterLink>
  </div>
</template>

<script setup lang="ts">
import { inject, type Ref } from 'vue';
import Form from '@/components/Form.vue'
import { useRouter } from 'vue-router'
const router = useRouter();


const addTransaction = inject<{ addTransaction: (new_date: string, description: string, amount: number) => void }>('transaction')!.addTransaction;

function onSubmit(new_date: string, description: string, amount: number) {
  addTransaction(new_date, description, amount);
  router.push("/")
}

</script>

<style scoped>
div {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #fff;
  box-shadow: 0 2px 5px rgba(0, 0, 0, .1);
}

.cancel-btn {
  display: inline-block;
  padding: 10px 20px;
  margin-top: 10px;
  background-color: #eee;
  color: #333;
  border: none;
  border-radius: 5px;

}

.cancel-btn:hover {
  background-color: #ddd;
}
</style>